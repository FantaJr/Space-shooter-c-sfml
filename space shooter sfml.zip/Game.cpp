#include "Game.h"
#include <iostream>

// Constructor
Game::Game() {
    this->initVariables();
    this->initWindow();
    this->initCharacter();
    this->initEnemies();
    this->initFontAndText();
    this->initBackground();
}

// Destructor
Game::~Game() {
    delete this->window;
}

// Initialize variables
void Game::initVariables() {
    this->window = nullptr;
    this->xPos = 960.0f; // Starting x position
    this->yPos = 540.0f; // Starting y position
    this->movementSpeed = 600.0f;
    this->enemyMovementSpeed = 300.0f;
    this->deltaTime = 0.0f;
}

// Initialize window
void Game::initWindow() {
    this->window = new sf::RenderWindow(sf::VideoMode(1920, 1080), "Test", sf::Style::Default);
}
// Initialize background
void Game::initBackground() {
    if (!this->backgroundTexture.loadFromFile("assets/bg.jpg")) {
        std::cerr << "Failed to load background texture!" << std::endl;
    }
    this->background.setTexture(this->backgroundTexture);
}

// Initialize character
void Game::initCharacter() {
    if (!this->characterTexture.loadFromFile("assets/spaceship.png")) {
        std::cerr << "Failed to load character texture!" << std::endl;
    }
    this->character.setTexture(this->characterTexture);
    this->character.setScale(0.3f, 0.3f); // Scale down the character (adjust as needed)
    this->character.setPosition(sf::Vector2f(this->xPos, this->yPos));
}

// Initialize enemies
void Game::initEnemies() {
    if (!this->enemyTexture.loadFromFile("assets/meteor.png")) {
        std::cerr << "Failed to load enemy texture!" << std::endl;
    }

    int currentEnemyCount = this->enemies.size(); // Mevcut d��man say�s�
    int newEnemyCount = this->enemyCount - currentEnemyCount; // Eklenecek yeni d��man say�s�

    for (int i = 0; i < newEnemyCount; i++) {
        sf::Sprite enemy;
        enemy.setTexture(this->enemyTexture);
        enemy.setScale(0.1f, 0.1f); // Scale down the enemy (adjust as needed)
        this->enemies.push_back(enemy);
        this->enemyXPos.push_back(rand() % 1920);
        this->enemyYPos.push_back(rand() % 1080);
    }
}

// Initialize font and text for timer
void Game::initFontAndText() {
    if (!this->font.loadFromFile("assets/MinecraftRegular-Bmg3.otf")) { // Ensure the font file is in the same directory as your executable
        std::cerr << "Failed to load font!" << std::endl;
    }
    this->timerText.setFont(this->font);
    this->timerText.setCharacterSize(50);
    this->timerText.setFillColor(sf::Color::White);
    this->timerText.setPosition(1700, 20); // Position the text in the top right corner
}

// Render game objects
void Game::render() {
    this->window->clear();
    this->window->draw(this->background);
    this->window->draw(this->character);
    this->drawEnemies();
    this->drawBullets();
    this->showTimer();
    this->window->display();
}

// Update game state
void Game::update() {
    this->deltaTime = this->clock.restart().asSeconds();
    this->pollEvents();
    this->moveCharacter();
    this->shootBullet();
    this->updateBullets();
    this->updateEnemy();
    this->checkCollision();
}

// Handle events
void Game::pollEvents() {
    while (this->window->pollEvent(this->event)) {
        switch (this->event.type) {
        case sf::Event::Closed:
            this->window->close();
            break;
        case sf::Event::KeyPressed:
            if (this->event.key.code == sf::Keyboard::Escape) this->window->close();
            break;
        }
    }
}

// Move character
void Game::moveCharacter() {
    float windowWidth = 1920.0f;
    float windowHeight = 1080.0f;

    float characterWidth = this->character.getGlobalBounds().width;
    float characterHeight = this->character.getGlobalBounds().height;

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {
        if (this->xPos - this->movementSpeed * this->deltaTime > 0) {
            this->xPos -= this->movementSpeed * this->deltaTime;
        }
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
        if (this->xPos + this->movementSpeed * this->deltaTime + characterWidth < windowWidth) {
            this->xPos += this->movementSpeed * this->deltaTime;
        }
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {
        if (this->yPos - this->movementSpeed * this->deltaTime > 0) {
            this->yPos -= this->movementSpeed * this->deltaTime;
        }
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
        if (this->yPos + this->movementSpeed * this->deltaTime + characterHeight < windowHeight) {
            this->yPos += this->movementSpeed * this->deltaTime;
        }
    }

    this->character.setPosition(sf::Vector2f(this->xPos, this->yPos));
}


// Shoot bullets
void Game::shootBullet() {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
        if (this->bulletClock.getElapsedTime().asSeconds() >= this->bulletCooldown) {
            sf::CircleShape bullet(this->bulletRadius);
            bullet.setFillColor(sf::Color::Red);
            bullet.setPosition(this->character.getPosition().x + this->character.getGlobalBounds().width / 2 - this->bulletRadius, this->character.getPosition().y);
            this->bullets.push_back(bullet);
            this->bulletClock.restart(); // Restart the clock after shooting
        }
    }
}

// Update bullet positions
void Game::updateBullets() {
    for (int i = 0; i < this->bullets.size(); i++) {
        this->bullets[i].move(0, -this->bulletSpeed * this->deltaTime);
        if (this->bullets[i].getPosition().y < 0) {
            this->bullets.erase(this->bullets.begin() + i);
            i--;
        }
    }
}

// Check collision
void Game::checkCollision() {
    for (int i = 0; i < this->bullets.size(); i++) {
        for (int j = 0; j < this->enemyCount; j++) {
            if (this->bullets[i].getGlobalBounds().intersects(this->enemies[j].getGlobalBounds())) {
                this->bullets.erase(this->bullets.begin() + i);
                this->enemyXPos[j] = rand() % 1920;
                this->enemyYPos[j] = -80;

                i--;

                break;
            }
        }
    }

    for (int i = 0; i < this->enemyCount; i++) {
        if (this->character.getGlobalBounds().intersects(this->enemies[i].getGlobalBounds())) {
            this->window->close();
        }
    }
}

// Show timer
void Game::showTimer() {
    static sf::Clock timerClock;
    sf::Time elapsed = timerClock.getElapsedTime();
    int seconds = static_cast<int>(elapsed.asSeconds());
    this->timerText.setString("Time: " + std::to_string(seconds));
    this->window->draw(this->timerText);
}

// Update enemy positions
void Game::updateEnemy() {
    for (int i = 0; i < this->enemyCount; i++) {
        this->enemyYPos[i] += this->enemyMovementSpeed * this->deltaTime;
        this->enemies[i].setPosition(sf::Vector2f(this->enemyXPos[i], this->enemyYPos[i]));
        if (this->enemyYPos[i] > 1080) {
            this->enemyXPos[i] = rand() % 1920;
            this->enemyYPos[i] = -80;
        }
    }
}

// Draw enemies
void Game::drawEnemies() {
    for (int i = 0; i < this->enemyCount; i++) {
        this->window->draw(this->enemies[i]);
    }
}

// Draw bullets
void Game::drawBullets() {
    for (int i = 0; i < this->bullets.size(); i++) {
        this->window->draw(this->bullets[i]);
    }
}

// Check if the game is running
const bool Game::running() const {
    return this->window->isOpen();
}