#pragma once

#include <SFML/Graphics.hpp>
#include <vector>

class Game {
public:
    // Constructor
    Game();

    // Destructor
    virtual ~Game();

    // Functions
    void update();
    void render();
    const bool running() const;

private:
    // Variables
    
    sf::Texture backgroundTexture; // Background texture
    sf::Sprite background; // Background sprite
    
    sf::RenderWindow* window;
    sf::Event event;
    sf::Clock clock;
    float deltaTime;
    float xPos, yPos;
    float movementSpeed;
    float enemyMovementSpeed;

    // Character
    sf::Texture characterTexture;
    sf::Sprite character;

    // Enemies (Meteors)
    std::vector<sf::Sprite> enemies;
    std::vector<float> enemyXPos;
    std::vector<float> enemyYPos;
    sf::Texture enemyTexture;
    int enemyCount = 5;
    
    // Bullets
    std::vector<sf::CircleShape> bullets;
    float bulletSpeed = 1200.0f;
    float bulletRadius = 8.0f;

    sf::Clock bulletClock; // Bullet clock
    const float bulletCooldown = 0.2f; // Bullet cooldown time in seconds

    // Timer
    sf::Font font;
    sf::Text timerText;

    // Private functions
    void initVariables();
    void initWindow();
    void initCharacter();
    void initEnemies();
    void initFontAndText();
    void initBackground();

    // Game loop functions
    void pollEvents();
    void moveCharacter();
    void shootBullet();
    void updateBullets();
    void updateEnemy();
    void checkCollision();
    void drawEnemies();
    void drawBullets();
    void showTimer();
};
